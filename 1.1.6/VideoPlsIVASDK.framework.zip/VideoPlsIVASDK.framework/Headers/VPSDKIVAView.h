//
//  VPSDKIVAView.h
//  VideoPlsIVASDK
//
//  Created by Zard1096 on 15/12/30.
//  Copyright (c) 2015年 videopls.com. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *  面向高级开发者,只有互动层,请将其置于合适位置以防阻挡手势.
 *  最佳位置为加载控制栏的下方,并且于手势层的上方,请不要将IVAView放入包含手势操作的View中
 *  Build Settings中的Other Linker Flags需要加入 -ObjC
 */

@interface VPSDKIVAView : UIView

#pragma 初始化
/**
 *  初始化(推荐)
 *
 *  @param frame                视图位置与大小
 *  @param url                  Url地址
 *  @param videoType            设置url地址类型
 *  @param isLive               是否为直播
 *
 *  @return 初始化对象实例
 *
 *  注:videoType 合并videoType中的直播,添加直播属性isLive
 *  0:八大视频网站地址(默认)
 *  1:可直接访问视频原地址(网络)/直播地址
 *  2(测试):需要我请求一次得到json格式集合(直接能播放的视频源)/直播地址集合
 *      使用方法:如为本地组装url请传 file://path
 *      主要用于多种清晰度,具体处理由你自行控制,本SDK只通过地址获取videoID
 *
 *  3(暂定):CDN
 *  4(暂定):深入合作方防盗链视频(通用包无效)
 *  -1:存于手机中的本地视频
 *
 *  -1,2(本地组装url)目前无法进行统计和视频交互
 *  注:本地文件无法获取唯一ID,加载不了交互,会报VPSDKIVAViewLoadErrorUrl错误
 */
- (id)initWithFrame:(CGRect)frame Url:(NSString *)url VideoType:(NSInteger)videoType isLive:(BOOL)isLive;

/**
 *  初始化时设置是否为直播属性
 */
- (void)setIsLive:(BOOL)isLive;

/**
 *  初始化时设置视频地址
 */
- (void)setUrl:(NSString *)url;

/**
 *  初始化时设置视频播放类型
 */
- (void)setVideoType:(NSInteger)videoType;

/**
 *  初始化设置视频标题,方便后台管理(可选,推荐)
 */
- (void)setVideoTitle:(NSString *)videoTitle;


//后台新增默认配置风车和云泡,如果在SDK中配置则已SDK配置优先
/**
 *  设置是否加载云泡 提供最终用户控制是否显示云泡方法setShowBubble:
 */
- (void)setEnableBubble:(BOOL)enable;

/**
 *  设置是否打开风车 暂不提供最终用户控制是否显示风车方法,用户可在后台配置风车
 *  直播暂无风车
 */
- (void)setEnableWindmill:(BOOL)enable;


//后台新增默认配置风车和云泡,可以获取到目前云链和云泡
/**
 *  获取目前云泡是否启用
 */
- (BOOL)getEnableBubble;

/**
 *  获取目前风车是否启用
 */
- (BOOL)getEnableWindmill;

/**
 *  初始化设置完成,开始加载
 */
- (void)startLoading;

/**
 *  结束播放必须调用,不然可能会无法释放
 */
- (void)stop;


#pragma 播放中需要持续调用的
/**
 *  设置当前播放时间,需设置一个计时器来调用
 *  间隔时间最好小于等于0.03s(30帧以上)来保证流畅的云链追踪
 *  请传入当前正在播放进度
 *  直播无需调用此方法
 *
 *  @param time 当前播放时间(毫秒)
 */
- (void)updateCurrentPlaybackTime:(NSTimeInterval)milliSecond;

#pragma 播放中参数调整
/**
 *  加载后能够设置
 *  设置IVAView大小和该视频具体位置大小
 *  IVAView与整体显示区域大小相当,videoRect与视频实际显示位置相同
 *  全屏显示互动,小窗不显示互动
 *
 *  @param frame        IVAView位置和大小
 *  @param videoRect    视频实际显示位置和大小
 *  @param isFullScreen 是否全屏
 */
- (void)updateFrame:(CGRect)frame videoRect:(CGRect)videoRect isFullScreen:(BOOL)isFullScreen;


#pragma 以下方法最好由用户行为进行控制,需要添加控制按钮
/**
 *  设置是否显示云链
 */
- (void)setShowVenvyTag:(BOOL)isShow;

/**
 *  设置是否显示云泡(不加载云泡无法调用)
 */
- (void)setShowBubble:(BOOL)isShow;


#pragma 获取method
/**
 *  获取云链是否显示(小屏默认为NO)
 */
- (BOOL)getVenvyTagIsShow;

/**
 *  获取云泡是否显示(小屏默认为NO)
 */
- (BOOL)getBubbleIsShow;


@end
