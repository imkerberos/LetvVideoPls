//
//  VPIVAPlayback.h
//  VideoPlsIVASDK
//
//  Created by Zard1096 on 15/12/31.
//  Copyright (c) 2015年 videopls.com. All rights reserved.
//

#import <Foundation/Foundation.h>

#pragma 通知
@interface VPIVAPlayback : NSObject

/**
 *  能在在自己应用内部打开外链的通知
 *  协议头为tomyapp:// 对应http:// ,topmyapps:// 对应https://
 *  userInfo
 *  Key:    LinkUrl
 *  Value:  即为你所需要的url,SDK会替换回http
 *  在编辑云窗时,添加的外链link对应是:http://xxxxx ,替换为 tomyapp://xxxxx
 */
extern NSString *const VPSDKMyAppLinkDidOpenNotification;

/**
 *  互动层加载完成
 */
extern NSString *const VPSDKIVAViewLoadCompleteNotification;

/**
 *  互动层加载信息
 *  userInfo
 *  Key:    ErrorState
 *  Value:  VPSDKIVAViewLoadErrorState
 */
extern NSString *const VPSDKIVAViewLoadErrorNotification;

/**
 *  云链/云窗被点击信息(有可能需要暂停或继续播放)
 *  userInfo
 *  Key:    VenvyTagState
 *  Value:  VPSDKIVAViewVenvyTagState
 */
extern NSString *const VPSDKIVAViewVenvyTagNotification;



#pragma optional 播放器事件通知
//可选,传递给我能协助我们互动层更加精准

/**
 *  播放器暂停或者播放通知
 *  userInfo
 *  Key:    PlaybackState
 *  Value:  VPSDKPlayerPlaybackState
 */
extern NSString *const VPSDKPlayerPauseOrPlayNotification;

/**
 *  播放器拖动通知
 *  userInfo
 *  Key:    SeekState
 *  Value:  VPSDKPlayerSeekState
 */
extern NSString *const VPSDKPlayerSeekingNotification;

/**
 *  播放器进入缓冲通知
 *  userInfo
 *  Key:    LoadState
 *  Value:  MPMovieLoadState
 *      MPMovieLoadStatePlaythroughOK缓冲结束
 *      MPMovieLoadStateStalled开始缓冲
 */
extern NSString *const VPSDKPlayerLoadStateDidChangeNotification;

/**
 *  播放器切换至竖屏或横屏
 *  userInfo
 *  Key:    screenState
 *  Value:  VPSDKPlayerScreenState
 */
extern NSString *const VPSDKPlayerScreenNotification;

@end

#pragma 通知中的枚举
/**
 *  错误状态枚举
 *  本地文件无法获取唯一ID,加载不了交互,会报VPSDKIVAViewLoadErrorUrl错误
 */
typedef NS_ENUM(NSInteger, VPSDKIVAViewLoadErrorState) {
    VPSDKIVAViewLoadErrorUrl,                   //错误的地址
    VPSDKIVAViewLoadErrorUrlFormat,             //错误的地址格式或为本地文件
    VPSDKIVAViewLoadErrorServer,                //连接服务器出错
    VPSDKIVAViewLoadErrorSlowConnecting,        //网络连接超时
    VPSDKIVAViewLoadErrorInvalidAppKey,         //无效Appkey
    VPSDKIVAViewLoadErrorInvalidBundleID,       //Appkey与bundleID不匹配
    VPSDKIVAViewLoadErrorNotComplete            //网络连接取消
};


/**
 *  交互状态枚举
 */
typedef NS_ENUM(NSInteger, VPSDKIVAViewVenvyTagState) {
    VPSDKIVAViewVenvyTagPausePlayer,            //云链被点击,打开云窗,右边遮住小半屏,可能需要暂停(最好隐藏控制栏)
    VPSDKIVAViewVenvyTagPlayPlayer,             //云窗关闭,如果之前控制暂停可以继续播放
    
    //如果不由SDK控制外链打开将没有以下两个状态
    VPSDKIVAViewVenvyDgPausePlayer,             //云窗的外链被点击,打开外链,需要暂停(最好隐藏控制栏)
    VPSDKIVAViewVenvyDgPlayPlayer               //云窗的外链关闭,可以继续播放
};

#pragma 可选,播放器通知的枚举
/**
 *  播放、暂停枚举
 */
typedef NS_ENUM(NSInteger, VPSDKPlayerPlaybackState) {
    VPSDKPlayerPause,                           //播放暂停
    VPSDKPlayerPlay                             //播放开始
};

typedef NS_ENUM(NSInteger, VPSDKPlayerSeekState) {
    VPSDKPlayerSeekStart,                       //开始跳转
    VPSDKPlayerSeekComplete                     //跳转结束
};

#pragma 屏幕状态
typedef NS_ENUM(NSInteger, VPSDKPlayerScreenState) {
    VPSDKPlayerPortrait,                        //切换至竖屏不做操作
    VPSDKPlayerPortraitRemoveDg,                //切换至竖屏移除云窗,如果打开WebView的状态下则都不消失(如果由SDK打开WebView)
    VPSDKPlayerPortraitRemoveDgAndWebView       //切换至竖屏移除云窗和webView(如果由SDK打开WebView)
};


