//
//  VideoPlsIVASDK.h
//  VideoPlsIVASDK
//
//  Created by Zard1096 on 15/12/30.
//  Copyright (c) 2015年 videopls.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <Foundation/Foundation.h>

@interface VideoPlsIVASDK : NSObject

/**
 *  设置AppKey(只能设置一次,不可重复设置)
 */
+ (void)setAppKey:(NSString *)appKey;

@end